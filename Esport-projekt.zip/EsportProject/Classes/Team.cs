﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EsportProject.Classes
{
    public class Teams
    {
        public string TeamName { get; set; }
        public int Matches { get; set; }
        public int Points { get; set; }
    }
}
