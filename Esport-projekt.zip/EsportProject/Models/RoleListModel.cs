﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EsportProject.Models
{
    public class RoleListModel
    {
        public string Name { get; set; }
        public bool Set { get; set; }
        public string id { get; set; }
    }
}
